state('alabama','al','montgomery',3894.0e+3,51.7e+3,22,'birmingham','mobile','montgomery','huntsville').
state('alaska','ak','juneau',401.8e+3,591.0e+3,49,'anchorage','fairbanks','juneau','sitka').
state('arizona','az','phoenix',2718.0e+3,114.0e+3,48,'phoenix','tucson','mesa','tempe').
state('arkansas','ar','little rock',2286.0e+3,53.2e+3,25,'little rock','fort smith','north little rock','pine bluff').
state('california','ca','sacramento',23.67e+6,158.0e+3,31,'los angeles','san diego','san francisco','san jose').
state('colorado','co','denver',2889.0e+3,104.0e+3,38,'denver','colorado springs','aurora','lakewood').
state('connecticut','ct','hartford',3107.0e+3,5.02e+3,5,'bridgeport','hartford','new haven','waterbury').
state('delaware','de','dover',594.0e+3,2044,1,'wilmington','newark','dover','brookside').
state('district of columbia', 'dc','washington',638.0e+3,1100,0,'tenleytown','washington','georgetown','duval circle').
state('florida','fl','tallahassee',9746.0e+3,68664,27,'jacksonville','miami','tampa','st. petersburg').
state('georgia','ga','atlanta',5463.0e+3,58.9e+3,4,'atlanta','columbus','savannah','macon').
state('hawaii','hi','honolulu',964.0e+3,6471,50,'honolulu','ewa','koolaupoko','wahiawa').
state('idaho','id','boise',944.0e+3,83.0e+3,43,'boise','pocatello','idaho falls','lewiston').
state('illinois','il','springfield',11.4e+6,56.3e+3,21,'chicago','rockford','peoria','springfield').
state('indiana','in','indianapolis',5490.0e+3,36.2e+3,19,'indianapolis','fort wayne','gary','evansville').
state('iowa','ia','des moines',2913.0e+3,56.3e+3,29,'des moines','cedar rapids','davenport','sioux city').
state('kansas','ks','topeka',2364.0e+3,82.3e+3,34,'wichita','kansas city','topeka','overland park').
state('kentucky','ky','frankfort',2364.0e+3,82.3e+3,15,'louisville','lexington','owensboro','covington').
state('louisiana','la','baton rouge',4206.0e+3,47.7e+3,18,'new orleans','baton rouge','shreveport','metairie').
state('maine','me','augusta',1125.0e+3,33265,23,'portland','lewiston','bangor','auburn').
state('maryland','md','annapolis',4217.0e+3,10460,7,'baltimore','silver spring','dundalk','bethesda').
state('massachusetts','ma','boston',5737.0e+3,8284,6,'boston','worcester','springfield','new bedford').
state('michigan','mi','lansing',9262.0e+3,58.5e+3,26,'detroit','grand rapids','warren','flint').
state('minnesota','mn','st. paul',4076.0e+3,84.4e+3,32,'minneapolis','st. paul','duluth','bloomington').
state('mississippi','ms','jackson',2520.0e+3,47.7e+3,20,'jackson','biloxi','meridian','hattiesburg').
state('missouri','mo','jefferson city',4916.0e+3,69.7e+3,24,'st. louis','kansas city','springfield','independence').
state('montana','mt','helena',786.7,147.0e+3,41,'billings','great falls','butte','missoula').
state('nebraska','ne','lincoln',1569.0e+3,77.3e+3,37,'omaha','lincoln','grand island','north platte').
state('nevada','nv','carson city',800.5e+3,110.5e+3,36,'las vegas','reno','sunrise manor','sparks').
state('new hampshire','nh','concord',920.6e+3,9279,9,'manchester','nashua','concord','portsmouth').
state('new jersey','nj','trenton',7365.0e+3,7787,3,'newark','jersey city','paterson','elizabeth').
state('new mexico','nm','santa fe',1303.0e+3,121.6e+3,47,'albuquerque','santa fe','las cruces','roswell').
state('new york','ny','albany',17.558e+6,49.1e+3,11,'new york','buffalo','rochester','yonkers').
state('north carolina','nc','raleigh',5882.0e+3,52.67e+3,12,'charlotte','greensboro','raleigh','winston-salem').
state('north dakota','nd','bismarck',652.7e+3,70.7e+3,39,'fargo','bismarck','grand forks','minot').
state('ohio','oh','columbus',10.8e+6,41.3e+3,17,'cleveland','columbus','cincinnati','toledo').
state('oklahoma','ok','oklahoma city',3025.0e+3,69.95e+3,46,'oklahoma city','tulsa','lawton','norman').
state('oregon','or','salem',2633.0e+3,97073,33,'portland','eugene','salem','springfield').
state('pennsylvania','pa','harrisburg',11.863e+6,45308,2,'philadelphia','pittsburgh','erie','allentown').
state('rhode island','ri','providence',947.2e+3,1212,13,'providence','warwick','cranston','pawtucket').
state('south carolina','sc','columbia',3121.8e+3,31.113e+3,8,'columbia','charleston','north charleston','greenville').
state('south dakota','sd','pierre',690.767e+3,77116,40,'sioux falls','rapid city','aberdeen','watertown').
state('tennessee','tn','nashville',4591.0e+3,42.14e+3,16,'memphis','nashville','knoxville','chattanooga').
state('texas','tx','austin',14.229e+6,266.807e+3,28,'houston','dallas','san antonio','el paso').
state('utah','ut','salt lake city',1461.0e+3,84.9e+3,45,'salt lake city','provo','west valley','ogden').
state('vermont','vt','montpelier',511.5e+3,9614,14,'burlington','rutland','bennington','essex').
state('virginia','va','richmond',5346.8e+3,40.76e+3,10,'norfolk','virginia beach','richmond','arlington').
state('washington','wa','olympia',41.132e+5,68.139e+3,42,'seattle','spokane','tacoma','bellevue').
state('west virginia','wv','charleston',1.95e+6,24.2e+3,35,'charleston','huntington','wheeling','parkersburg').
state('wisconsin','wi','madison',4.7e+6,56153,30,'milwaukee','madison','green bay','racine').
state('wyoming','wy','cheyenne',469.557e+3,97.809e+3,44,'casper','cheyenne','laramie','rock springs').
city('alabama','al','birmingham',284413).
city('alabama','al','mobile',200452).
city('alabama','al','montgomery',177857).
city('alabama','al','huntsville',142513).
city('alabama','al','tuscaloosa',75143).
city('alaska','ak','anchorage',174431).
city('arizona','az','phoenix',789704).
city('arizona','az','tucson',330537).
city('arizona','az','mesa',152453).
city('arizona','az','tempe',106919).
city('arizona','az','glendale',96988).
city('arizona','az','scottsdale',88622).
city('arkansas','ar','little rock',158915).
city('arkansas','ar','fort smith',71384).
city('arkansas','ar','north little rock',64388).
city('california','ca','los angeles',2966850).
city('california','ca','san diego',875538).
city('california','ca','san francisco',678974).
city('california','ca','san jose',629442).
city('california','ca','long beach',361334).
city('california','ca','oakland',339337).
city('california','ca','sacramento',275741).
city('california','ca','anaheim',219311).
city('california','ca','fresno',218202).
city('california','ca','santa ana',203713).
city('california','ca','riverside',170876).
city('california','ca','huntington beach',170505).
city('california','ca','stockton',149779).
city('california','ca','glendale',139060).
city('california','ca','fremont',131945).
city('california','ca','torrance',131497).
city('california','ca','garden grove',123351).
city('california','ca','san bernardino',118794).
city('california','ca','pasadena',118072).
city('california','ca','east los angeles',110017).
city('california','ca','oxnard',108195).
city('california','ca','modesto',106963).
city('california','ca','sunnyvale',106618).
city('california','ca','bakersfield',105611).
city('california','ca','concord',103763).
city('california','ca','berkeley',103328).
city('california','ca','fullerton',102246).
city('california','ca','inglewood',94162).
city('california','ca','hayward',93585).
city('california','ca','pomona',92742).
city('california','ca','orange',91450).
city('california','ca','ontario',88820).
city('california','ca','santa monica',88314).
city('california','ca','santa clara',87700).
city('california','ca','citrus heights',85911).
city('california','ca','norwalk',84901).
city('california','ca','burbank',84625).
city('california','ca','chula vista',83927).
city('california','ca','santa rosa',83205).
city('california','ca','downey',82602).
city('california','ca','costa mesa',82291).
city('california','ca','compton',81230).
city('california','ca','carson',81221).
city('california','ca','salinas',80479).
city('california','ca','west covina',80292).
city('california','ca','vallejo',80188).
city('california','ca','el monte',79494).
city('california','ca','daly city',78519).
city('california','ca','thousand oaks',77797).
city('california','ca','san mateo',77640).
city('california','ca','simi valley',77500).
city('california','ca','oceanside',76698).
city('california','ca','richmond',74676).
city('california','ca','lakewood',74654).
city('california','ca','santa barbara',74542).
city('california','ca','el cajon',73892).
city('california','ca','ventura',73774).
city('california','ca','westminster',71133).
city('california','ca','whittier',68558).
city('california','ca','south gate',66784).
city('california','ca','alhambra',64767).
city('california','ca','buena park',64165).
city('california','ca','san leandro',63952).
city('california','ca','alameda',63852).
city('california','ca','newport beach',63475).
city('california','ca','escondido',62480).
city('california','ca','irvine',62134).
city('california','ca','mountain view',58655).
city('california','ca','fairfield',58099).
city('california','ca','redondo beach',57102).
city('california','ca','scotts valley',6037).
city('colorado','co','denver',492365).
city('colorado','co','colorado springs',215150).
city('colorado','co','aurora',158588).
city('colorado','co','lakewood',113808).
city('colorado','co','pueblo',101686).
city('colorado','co','arvada',84576).
city('colorado','co','boulder',76685).
city('colorado','co','fort collins',64632).
city('connecticut','ct','bridgeport',142546).
city('connecticut','ct','hartford',136392).
city('connecticut','ct','new haven',126089).
city('connecticut','ct','waterbury',103266).
city('connecticut','ct','stamford',102466).
city('connecticut','ct','norwalk',77767).
city('connecticut','ct','new britain',73840).
city('connecticut','ct','west hartford',61301).
city('connecticut','ct','danbury',60470).
city('connecticut','ct','greenwich',59578).
city('connecticut','ct','bristol',57370).
city('connecticut','ct','meriden',57118).
city('delaware','de','wilmington',70195).
city('district of columbia','dc','washington',638333).
city('florida','fl','jacksonville',540920).
city('florida','fl','miami',346865).
city('florida','fl','tampa',271523).
city('florida','fl','st. petersburg',238647).
city('florida','fl','fort lauderdale',153256).
city('florida','fl','orlando',128394).
city('florida','fl','hollywood',117188).
city('florida','fl','miami beach',96298).
city('florida','fl','clearwater',85450).
city('florida','fl','tallahassee',81548).
city('florida','fl','gainesville',81371).
city('florida','fl','kendall',73758).
city('florida','fl','west palm beach',62530).
city('florida','fl','largo',58977).
city('florida','fl','pensacola',57619).
city('georgia','ga','atlanta',425022).
city('georgia','ga','columbus',169441).
city('georgia','ga','savannah',141654).
city('georgia','ga','macon',116860).
city('georgia','ga','albany',74425).
city('hawaii','hi','honolulu',762874).
city('hawaii','hi','ewa',190037).
city('hawaii','hi','koolaupoko',109373).
city('idaho','id','boise',102249).
city('illinois','il','chicago',3005172).
city('illinois','il','rockford',139712).
city('illinois','il','peoria',124160).
city('illinois','il','springfield',100054).
city('illinois','il','decatur',93939).
city('illinois','il','aurora',81293).
city('illinois','il','joliet',77956).
city('illinois','il','evanston',73706).
city('illinois','il','waukegan',67653).
city('illinois','il','arlington heights',66116).
city('illinois','il','elgin',63668).
city('illinois','il','cicero',61232).
city('illinois','il','oak lawn',60590).
city('illinois','il','skokie',60278).
city('illinois','il','champaign',58267).
city('indiana','in','indianapolis',700807).
city('indiana','in','fort wayne',172196).
city('indiana','in','gary',151968).
city('indiana','in','evansville',130496).
city('indiana','in','south bend',109727).
city('indiana','in','hammond',93714).
city('indiana','in','muncie',77216).
city('indiana','in','anderson',64695).
city('indiana','in','terre haute',61125).
city('iowa','ia','des moines',191003).
city('iowa','ia','cedar rapids',110243).
city('iowa','ia','davenport',103254).
city('iowa','ia','sioux city',82003).
city('iowa','ia','waterloo',75985).
city('iowa','ia','dubuque',62321).
city('kansas','ks','wichita',279212).
city('kansas','ks','kansas city',161148).
city('kansas','ks','topeka',118690).
city('kansas','ks','overland park',81784).
city('kentucky','ky','louisville',298451).
city('kentucky','ky','lexington',204165).
city('louisiana','la','new orleans',557515).
city('louisiana','la','baton rouge',219419).
city('louisiana','la','shreveport',205820).
city('louisiana','la','metairie',164160).
city('louisiana','la','lafayette',80584).
city('louisiana','la','lake charles',75051).
city('louisiana','la','kenner',66382).
city('louisiana','la','monroe',57597).
city('maine','me','portland',61572).
city('maryland','md','baltimore',786775).
city('maryland','md','silver spring',72893).
city('maryland','md','dundalk',71293).
city('maryland','md','bethesda',63022).
city('massachusetts','ma','boston',562994).
city('massachusetts','ma','worcester',161799).
city('massachusetts','ma','springfield',152319).
city('massachusetts','ma','new bedford',98478).
city('massachusetts','ma','cambridge',95322).
city('massachusetts','ma','brockton',95172).
city('massachusetts','ma','fall river',92574).
city('massachusetts','ma','lowell',92418).
city('massachusetts','ma','quincy',84743).
city('massachusetts','ma','newton',83622).
city('massachusetts','ma','lynn',78471).
city('massachusetts','ma','somerville',77372).
city('massachusetts','ma','framingham',65113).
city('massachusetts','ma','lawrence',63175).
city('massachusetts','ma','waltham',58200).
city('massachusetts','ma','medford',58076).
city('michigan','mi','detroit',1203339).
city('michigan','mi','grand rapids',181843).
city('michigan','mi','warren',161134).
city('michigan','mi','flint',159611).
city('michigan','mi','lansing',130414).
city('michigan','mi','sterling heights',108999).
city('michigan','mi','ann arbor',107969).
city('michigan','mi','livonia',104814).
city('michigan','mi','dearborn',90660).
city('michigan','mi','westland',84603).
city('michigan','mi','kalamazoo',79722).
city('michigan','mi','taylor',77568).
city('michigan','mi','saginaw',77508).
city('michigan','mi','pontiac',76715).
city('michigan','mi','st. clair shores',76210).
city('michigan','mi','southfield',75568).
city('michigan','mi','clinton',72400).
city('michigan','mi','royal oak',70893).
city('michigan','mi','dearborn heights',67706).
city('michigan','mi','troy',67102).
city('michigan','mi','waterford',64250).
city('michigan','mi','wyoming',59616).
city('michigan','mi','redford',58441).
city('michigan','mi','farmington hills',58056).
city('minnesota','mn','minneapolis',370951).
city('minnesota','mn','st. paul',270230).
city('minnesota','mn','duluth',92811).
city('minnesota','mn','bloomington',81831).
city('minnesota','mn','rochester',57906).
city('mississippi','ms','jackson',202895).
city('missouri','mo','st. louis',453085).
city('missouri','mo','kansas city',448159).
city('missouri','mo','springfield',133116).
city('missouri','mo','independence',111797).
city('missouri','mo','st. joseph',76691).
city('missouri','mo','columbia',62061).
city('montana','mt','billings',66842).
city('montana','mt','great falls',56725).
city('nebraska','ne','omaha',314255).
city('nebraska','ne','lincoln',171932).
city('nevada','nv','las vegas',164674).
city('nevada','nv','reno',100756).
city('new hampshire','nh','manchester',90936).
city('new hampshire','nh','nashua',67865).
city('new jersey','nj','newark',329248).
city('new jersey','nj','jersey city',223532).
city('new jersey','nj','paterson',137970).
city('new jersey','nj','elizabeth',106201).
city('new jersey','nj','trenton',92124).
city('new jersey','nj','woodbridge',90074).
city('new jersey','nj','camden',84910).
city('new jersey','nj','east orange',77878).
city('new jersey','nj','clifton',74388).
city('new jersey','nj','edison',70193).
city('new jersey','nj','cherry hill',68785).
city('new jersey','nj','bayonne',65047).
city('new jersey','nj','middletown',61615).
city('new jersey','nj','irvington',61493).
city('new mexico','nm','albuquerque',331767).
city('new york','ny','new york',7071639).
city('new york','ny','buffalo',357870).
city('new york','ny','rochester',241741).
city('new york','ny','yonkers',195351).
city('new york','ny','syracuse',170105).
city('new york','ny','albany',101727).
city('new york','ny','cheektowaga',92145).
city('new york','ny','utica',75632).
city('new york','ny','niagara falls',71384).
city('new york','ny','new rochelle',70794).
city('new york','ny','schenectady',67972).
city('new york','ny','mount vernon',66713).
city('new york','ny','irondequoit',57648).
city('new york','ny','levittown',57045).
city('north carolina','nc','charlotte',314447).
city('north carolina','nc','greensboro',155642).
city('north carolina','nc','raleigh',149771).
city('north carolina','nc','winston-salem',131885).
city('north carolina','nc','durham',100538).
city('north carolina','nc','high point',64107).
city('north carolina','nc','fayetteville',59507).
city('north dakota','nd','fargo',61308).
city('ohio','oh','cleveland',573822).
city('ohio','oh','columbus',564871).
city('ohio','oh','cincinnati',385457).
city('ohio','oh','toledo',354635).
city('ohio','oh','akron',237177).
city('ohio','oh','dayton',203371).
city('ohio','oh','youngstown',115436).
city('ohio','oh','canton',93077).
city('ohio','oh','parma',92548).
city('ohio','oh','lorain',75416).
city('ohio','oh','springfield',72563).
city('ohio','oh','hamilton',63189).
city('ohio','oh','lakewood',61963).
city('ohio','oh','kettering',61186).
city('ohio','oh','euclid',59999).
city('ohio','oh','elyria',57504).
city('oklahoma','ok','oklahoma city',403213).
city('oklahoma','ok','tulsa',360919).
city('oklahoma','ok','lawton',80054).
city('oklahoma','ok','norman',68020).
city('oregon','or','portland',366383).
city('oregon','or','eugene',105664).
city('oregon','or','salem',89233).
city('pennsylvania','pa','philadelphia',1688210).
city('pennsylvania','pa','pittsburgh',423938).
city('pennsylvania','pa','erie',119123).
city('pennsylvania','pa','allentown',103758).
city('pennsylvania','pa','scranton',88117).
city('pennsylvania','pa','upper darby',84054).
city('pennsylvania','pa','reading',78686).
city('pennsylvania','pa','bethlehem',70419).
city('pennsylvania','pa','lower merion',59651).
city('pennsylvania','pa','abingdon',59084).
city('pennsylvania','pa','bristol township',58733).
city('pennsylvania','pa','penn hills',57632).
city('pennsylvania','pa','altoona',57078).
city('rhode island','ri','providence',156804).
city('rhode island','ri','warwick',87123).
city('rhode island','ri','cranston',71992).
city('rhode island','ri','pawtucket',71204).
city('south carolina','sc','columbia',101229).
city('south carolina','sc','charleston',69855).
city('south carolina','sc','north charleston',62504).
city('south carolina','sc','greenville',58242).
city('south dakota','sd','sioux falls',81343).
city('tennessee','tn','memphis',646356).
city('tennessee','tn','nashville',455651).
city('tennessee','tn','knoxville',175030).
city('tennessee','tn','chattanooga',169728).
city('texas','tx','houston',1595138).
city('texas','tx','dallas',904078).
city('texas','tx','san antonio',785880).
city('texas','tx','el paso',425259).
city('texas','tx','fort worth',385164).
city('texas','tx','austin',345496).
city('texas','tx','corpus christi',231999).
city('texas','tx','lubbock',173979).
city('texas','tx','arlington',160123).
city('texas','tx','amarillo',149230).
city('texas','tx','garland',138857).
city('texas','tx','beaumont',118102).
city('texas','tx','pasadena',112560).
city('texas','tx','irving',109943).
city('texas','tx','waco',101261).
city('texas','tx','abilene',98315).
city('texas','tx','wichita falls',94201).
city('texas','tx','laredo',91449).
city('texas','tx','odessa',90027).
city('texas','tx','brownsville',84997).
city('texas','tx','san angelo',73240).
city('texas','tx','richardson',72496).
city('texas','tx','plano',72331).
city('texas','tx','grand prairie',71462).
city('texas','tx','midland',70525).
city('texas','tx','tyler',70508).
city('texas','tx','mesquite',67053).
city('texas','tx','mcallen',67042).
city('texas','tx','longview',62762).
city('texas','tx','port arthur',61195).
city('utah','ut','salt lake city',163034).
city('utah','ut','provo',74111).
city('utah','ut','west valley',72299).
city('utah','ut','ogden',64407).
city('virginia','va','norfolk',266979).
city('virginia','va','virginia beach',262199).
city('virginia','va','richmond',219214).
city('virginia','va','arlington',152599).
city('virginia','va','newport news',144903).
city('virginia','va','hampton',122617).
city('virginia','va','chesapeake',114226).
city('virginia','va','portsmouth',104577).
city('virginia','va','alexandria',103217).
city('virginia','va','roanoke',100427).
city('virginia','va','lynchburg',66743).
city('washington','wa','seattle',493846).
city('washington','wa','spokane',171300).
city('washington','wa','tacoma',158501).
city('washington','wa','bellevue',73903).
city('west virginia','wv','charleston',63968).
city('west virginia','wv','huntington',63684).
city('wisconsin','wi','milwaukee',636212).
city('wisconsin','wi','madison',170616).
city('wisconsin','wi','green bay',87899).
city('wisconsin','wi','racine',85725).
city('wisconsin','wi','kenosha',77685).
city('wisconsin','wi','west allis',63982).
city('wisconsin','wi','appleton',58913).
city('wyoming','wy','casper',51016).
river('mississippi',3778,['minnesota','wisconsin','iowa','illinois','missouri','kentucky','tennessee','arkansas','mississippi','louisiana','louisiana']).
river('missouri',3968,['montana','north dakota','south dakota','iowa','nebraska','missouri','missouri']).
river('colorado',2333,['colorado','utah','arizona','nevada','california']).
river('ohio',1569,['pennsylvania','west virginia','kentucky','indiana','illinois','illinois','ohio']).
river('red',1638,['new mexico','texas','oklahoma','arkansas','arkansas','louisiana']).
river('arkansas',2333,['colorado','kansas','oklahoma','arkansas']).
river('canadian',1458,['colorado','new mexico','texas','oklahoma']).
river('connecticut',655,['new hampshire','vermont','massachusetts','connecticut']).
river('delaware',451,['new york','pennsylvania','new jersey','delaware']).
river('little missouri',901,['wyoming','montana','south dakota','north dakota']).
river('snake',1670,['wyoming','idaho','oregon','washington','washington']).
river('chattahoochee',702,['georgia','georgia','florida']).
river('cimarron',965,['new mexico','kansas','oklahoma']).
river('green',1175,['wyoming','utah','colorado','utah']).
river('north platte',1094,['colorado','wyoming','nebraska']).
river('potomac',462,['west virginia','maryland','virginia','district of columbia']).
river('republican',679,['colorado','nebraska','kansas']).
river('rio grande',3033,['colorado','new mexico','texas']).
river('san juan',579,['colorado','new mexico','colorado','utah']).
river('tennessee',1049,['tennessee','alabama','tennessee','kentucky']).
river('wabash',764,['ohio','indiana','illinois']).
river('yellowstone',1080,['wyoming','montana','north dakota']).
river('allegheny',523,['pennsylvania','new york','pennsylvania']).
river('bighorn',541,['wyoming','montana']).
river('cheyenne',848,['wyoming','north dakota']).
river('clark fork',483,['montana','idaho']).
river('columbia',1953,['washington','oregon']).
river('cumberland',1105,['kentucky','tennessee','kentucky']).
river('dakota',1142,['north dakota','south dakota']).
river('gila',805,['new mexico','arizona']).
river('hudson',492,['new york','new jersey']).
river('neosho',740,['kansas','oklahoma']).
river('niobrara',693,['wyoming','nebraska']).
river('ouachita',973,['arkansas','louisiana']).
river('pearl',788,['michigan','louisiana']).
river('pecos',805,['new mexico','texas']).
river('powder',603,['wyoming','montana']).
river('roanoke',660,['virginia','north carolina']).
river('rock',459,['wisconsin','illinois']).
river('smoky hill',869,['colorado','kansas']).
river('south platte',682,['colorado','nebraska']).
river('st. francis',684,['missouri','arkansas']).
river('tombigbee',658,['mississippi','alabama']).
river('washita',805,['texas','oklahoma']).
river('wateree catawba',636,['north carolina','south carolina']).
river('white',1110,['arkansas','missouri','arkansas']).
border('alabama','al',['tennessee','georgia','florida','mississippi']).
border('alaska','ak',[]).
border('arizona','az',['utah','colorado','new mexico','california','nevada']).
border('arkansas','ar',['missouri','tennessee','mississippi','louisiana','texas','oklahoma']).
border('california','ca',['oregon','nevada','arizona']).
border('colorado','co',['nebraska','kansas','oklahoma','new mexico','arizona','utah','wyoming']).
border('connecticut','ct',['massachusetts','rhode island','new york']).
border('delaware','de',['pennsylvania','new jersey','maryland']).
border('district of columbia','dc',['maryland','virginia']).
border('florida','fl',['georgia','alabama']).
border('georgia','ga',['north carolina','south carolina','florida','alabama','tennessee']).
border('hawaii','hi',[]).
border('idaho','id',['montana','wyoming','utah','nevada','oregon','washington']).
border('illinois','il',['wisconsin','indiana','kentucky','missouri','iowa']).
border('indiana','in',['michigan','ohio','kentucky','illinois']).
border('iowa','ia',['minnesota','wisconsin','illinois','missouri','nebraska','south dakota']).
border('kansas','ks',['nebraska','missouri','oklahoma','colorado']).
border('kentucky','ky',['indiana','ohio','west virginia','virginia','tennessee','missouri','illinois']).
border('louisiana','la',['arkansas','mississippi','texas']).
border('maine','me',['new hampshire']).
border('maryland','md',['pennsylvania','delaware','virginia','district of columbia','west virginia']).
border('massachusetts','ma',['new hampshire','rhode island','connecticut','new york','vermont']).
border('michigan','mi',['ohio','indiana','wisconsin']).
border('minnesota','mn',['wisconsin','iowa','south dakota','north dakota']).
border('mississippi','ms',['tennessee','alabama','louisiana','arkansas']).
border('missouri','mo',['iowa','illinois','kentucky','tennessee','arkansas','oklahoma','kansas','nebraska']).
border('montana','mt',['north dakota','south dakota','wyoming','idaho']).
border('nebraska','ne',['south dakota','iowa','missouri','kansas','colorado','wyoming']).
border('nevada','nv',['idaho','utah','arizona','california','oregon']).
border('new hampshire','nh',['maine','massachusetts','vermont']).
border('new jersey','nj',['new york','delaware','pennsylvania']).
border('new mexico','nm',['colorado','oklahoma','texas','arizona','utah']).
border('new york','ny',['vermont','massachusetts','connecticut','new jersey','pennsylvania']).
border('north carolina','nc',['virginia','south carolina','georgia','tennessee']).
border('north dakota','nd',['minnesota','south dakota','montana']).
border('ohio','oh',['michigan','pennsylvania','west virginia','kentucky','indiana']).
border('oklahoma','ok',['kansas','missouri','arkansas','texas','new mexico','colorado']).
border('oregon','or',['washington','idaho','nevada','california']).
border('pennsylvania','pa',['new york','new jersey','delaware','maryland','west virginia','ohio']).
border('rhode island','ri',['massachusetts','connecticut']).
border('south carolina','sc',['north carolina','georgia']).
border('south dakota','sd',['north dakota','minnesota','iowa','nebraska','wyoming','montana']).
border('tennessee','tn',['kentucky','virginia','north carolina','georgia','alabama','mississippi','arkansas','missouri']).
border('texas','tx',['oklahoma','arkansas','louisiana','new mexico']).
border('utah','ut',['wyoming','colorado','new mexico','arizona','nevada','idaho']).
border('vermont','vt',['new hampshire','massachusetts','new york']).
border('virginia','va',['maryland','district of columbia','north carolina','tennessee','kentucky','west virginia']).
border('washington','wa',['idaho','oregon']).
border('west virginia','wv',['pennsylvania','maryland','virginia','kentucky','ohio']).
border('wisconsin','wi',['michigan','illinois','iowa','minnesota']).
border('wyoming','wy',['montana','south dakota','nebraska','colorado','utah','idaho']).
highlow('alabama','al','cheaha mountain',734,'gulf of mexico',0).
highlow('alaska','ak','mount mckinley',6194,'pacific ocean',0).
highlow('arizona','az','humphreys peak',3851,'colorado river',21).
highlow('arkansas','ar','magazine mountain',839,'ouachita river',17).
highlow('california','ca','mount whitney',4418,'death valley',-85).
highlow('colorado','co','mount elbert',4399,'arkansas river',1021).
highlow('connecticut','ct','mount frissell',725,'long island sound',0).
highlow('delaware','de','centerville',135,'atlantic ocean',0).
highlow('district of columbia','dc','tenleytown',125,'potomac river',0).
highlow('florida','fl','walton county',105,'atlantic ocean',0).
highlow('georgia','ga','brasstown bald',1458,'atlantic ocean',0).
highlow('hawaii','hi','mauna kea',4205,'pacific ocean',0).
highlow('idaho','id','borah peak',3859,'snake river',216).
highlow('illinois','il','charles mound',376,'mississippi river',85).
highlow('indiana','in','franklin township',383,'ohio river',98).
highlow('iowa','ia','ocheyedan mound',511,'mississippi river',146).
highlow('kansas','ks','mount sunflower',1231,'verdigris river',207).
highlow('kentucky','ky','black mountain',1263,'mississippi river',78).
highlow('louisiana','la','driskill mountain',163,'new orleans',-1).
highlow('maine','me','mount katahdin',1606,'atlantic ocean',0).
highlow('maryland','md','backbone mountain',1024,'atlantic ocean',0).
highlow('massachusetts','ma','mount greylock',1064,'atlantic ocean',0).
highlow('michigan','mi','mount curwood',604,'lake erie',174).
highlow('minnesota','mn','eagle mountain',701,'lake superior',183).
highlow('mississippi','ms','woodall mountain',246,'gulf of mexico',0).
highlow('missouri','mo','taum sauk mountain',540,'st. francis river',70).
highlow('montana','mt','granite peak',3901,'kootenai river',549).
highlow('nebraska','ne','johnson township',1654,'southeast corner',256).
highlow('nevada','nv','boundary peak',4005,'colorado river',143).
highlow('new hampshire','nh','mount washington',1917,'atlantic ocean',0).
highlow('new jersey','nj','high point',550,'atlantic ocean',0).
highlow('new mexico','nm','wheeler peak',4011,'red bluff reservoir',859).
highlow('new york','ny','mount marcy',1629,'atlantic ocean',0).
highlow('north carolina','nc','mount mitchell',2037,'atlantic ocean',0).
highlow('north dakota','nd','white butte',1069,'red river',229).
highlow('ohio','oh','campbell hill',472,'ohio river',132).
highlow('oklahoma','ok','black mesa',1516,'little river',87).
highlow('oregon','or','mount hood',3424,'pacific ocean',0).
highlow('pennsylvania','pa','mount davis',979,'delaware river',0).
highlow('rhode island','ri','jerimoth hill',247,'atlantic ocean',0).
highlow('south carolina','sc','sassafras mountain',1085,'atlantic ocean',0).
highlow('south dakota','sd','harney peak',2207,'big stone lake',284).
highlow('tennessee','tn','clingmans dome',2025,'mississippi river',55).
highlow('texas','tx','guadalupe peak',2667,'gulf of mexico',0).
highlow('utah','ut','kings peak',4123,'beaver dam creek',610).
highlow('vermont','vt','mount mansfield',1339,'lake champlain',29).
highlow('virginia','va','mount rogers',1746,'atlantic ocean',0).
highlow('washington','wa','mount rainier',4392,'pacific ocean',0).
highlow('west virginia','wv','spruce knob',1482,'potomac river',73).
highlow('wisconsin','wi','timms hill',595,'lake michigan',177).
highlow('wyoming','wy','gannett peak',4202,'belle fourche river',945).
mountain('alaska','ak','mckinley',6194).
mountain('alaska','ak','st. elias',5489).
mountain('alaska','ak','foraker',5304).
mountain('alaska','ak','bona',5044).
mountain('alaska','ak','blackburn',4996).
mountain('alaska','ak','kennedy',4964).
mountain('alaska','ak','sanford',4949).
mountain('alaska','ak','south buttress',4842).
mountain('alaska','ak','vancouver',4785).
mountain('alaska','ak','churchill',4766).
mountain('alaska','ak','fairweather',4663).
mountain('alaska','ak','hubbard',4577).
mountain('alaska','ak','bear',4520).
mountain('alaska','ak','east buttress',4490).
mountain('alaska','ak','hunter',4442).
mountain('alaska','ak','alverstone',4439).
mountain('alaska','ak','browne tower',4429).
mountain('california','ca','whitney',4418).
mountain('colorado','co','elbert',4399).
mountain('colorado','co','massive',4396).
mountain('colorado','co','harvard',4395).
mountain('washington','wa','rainier',4392).
mountain('california','ca','williamson',4382).
mountain('colorado','co','bianca',4372).
mountain('colorado','co','la plata',4370).
mountain('colorado','co','uncompahgre',4361).
mountain('colorado','co','crestone',4357).
mountain('colorado','co','lincoln',4354).
mountain('colorado','co','grays',4349).
mountain('colorado','co','antero',4349).
mountain('colorado','co','torreys',4349).
mountain('colorado','co','castle',4348).
mountain('colorado','co','quandary',4348).
mountain('colorado','co','evans',4348).
mountain('colorado','co','longs',4345).
mountain('colorado','co','wilson',4342).
mountain('california','ca','white',4342).
mountain('california','ca','north palisade',4341).
mountain('colorado','co','shavano',4337).
mountain('colorado','co','belford',4327).
mountain('colorado','co','princeton',4327).
mountain('colorado','co','crestone needle',4327).
mountain('colorado','co','yale',4327).
mountain('colorado','co','bross',4320).
mountain('colorado','co','kit carson',4317).
mountain('alaska','ak','wrangell',4317).
mountain('california','ca','shasta',4317).
mountain('california','ca','sill',4317).
mountain('colorado','co','el diente',4316).
mountain('colorado','co','maroon',4315).
road('95',['maine','new hampshire','rhode island','connecticut','new york','new jersey','delaware','maryland','district of columbia','virginia','north carolina','south carolina','georgia','florida']).
road('90',['massachusetts','new york','pennsylvania','ohio','indiana','illinois','wisconsin','minnesota','south dakota','wyoming','montana','idaho','washington']).
road('80',['new york','new jersey','pennsylvania','ohio','indiana','illinois','iowa','nebraska','wyoming','utah','nevada','california']).
road('70',['district of columbia','maryland','pennsylvania','ohio','indiana','illinois','missouri','kansas','colorado','utah']).
road('10',['florida','alabama','mississippi','louisiana','texas','new mexico','arizona','california']).
road('40',['north carolina','tennessee','arkansas','oklahoma','texas','new mexico','arizona','california']).
road('15',['montana','idaho','utah','arizona','nevada','california']).
road('20',['south carolina','georgia','alabama','mississippi','louisiana','texas']).
road('35',['minnesota','iowa','missouri','kansas','oklahoma','texas']).
road('55',['illinois','missouri','arkansas','tennessee','mississippi','louisiana']).
road('64',['virginia','west virginia','kentucky','indiana','illinois','missouri']).
road('75',['michigan','ohio','kentucky','tennessee','georgia','florida']).
road('81',['new york','pennsylvania','maryland','west virginia','virginia','tennessee']).
road('77',['ohio','west virginia','virginia','north carolina','south carolina']).
road('85',['virginia','north carolina','south carolina','georgia','alabama']).
road('94',['illinois','wisconsin','minnesota','north dakota','montana']).
road('29',['north dakota','south dakota','iowa','missouri']).
road('65',['indiana','kentucky','tennessee','alabama']).
road('84',['connecticut','new york','new jersey','pennsylvania']).
road('5',['washington','oregon','california']).
road('24',['tennessee','kentucky','illinois']).
road('25',['wyoming','colorado','new mexico']).
road('44',['missouri','oklahoma','texas']).
road('59',['tennessee','georgia','alabama']).
road('74',['ohio','indiana','illinois']).
road('78',['new york','new jersey','pennsylvania']).
road('84',['utah','idaho','oregon']).
road('91',['vermont','massachusetts','connecticut']).
road('93',['new hampshire','vermont','massachusetts']).
road('8',['arizona','california']).
road('30',['arkansas','texas']).
road('57',['illinois','missouri']).
road('66',['district of columbia','virginia']).
road('69',['michigan','indiana']).
road('71',['ohio','kentucky']).
road('76',['nebraska','colorado']).
road('79',['pennsylvania','west virginia']).
road('83',['pennsylvania','maryland']).
road('86',['massachusetts','connecticut']).
road('89',['vermont','new hampshire']).
lake('superior',82362,['michigan','wisconsin','minnesota']).
lake('huron',59570,['michigan']).
lake('michigan',58016,['michigan','indiana','illinois','wisconsin']).
lake('erie',25667,['new york','pennsylvania','ohio','michigan']).
lake('ontario',19684,['new york']).
lake('great salt lake',5180,['utah']).
lake('lake of the woods',4391,['minnesota']).
lake('iliamna',2675,['alaska']).
lake('okeechobee',1810,['florida']).
lake('pontchartrain',1632,['louisiana']).
lake('becharof',1186,['alaska']).
lake('red',1169,['minnesota']).
lake('st. clair',1119,['michigan']).
lake('champlain',1114,['vermont','new york']).
lake('rainy',932,['minnesota']).
lake('salton sea',932,['california']).
lake('teshekpuk',816,['alaska']).
lake('naknek',630,['alaska']).
lake('winnebago',557,['wisconsin']).
lake('mille lacs',536,['minnesota']).
lake('flathead',510,['montana']).
lake('tahoe',497,['nevada','california']).

